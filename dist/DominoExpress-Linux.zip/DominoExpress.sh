#!/bin/sh
java  -jar DominoExpress.jar
        